package serviciosDB;

import javax.ejb.Local;

@Local
public interface ServiciosUsuarioLocal {

}
